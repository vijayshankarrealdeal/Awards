import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MusicStream extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
