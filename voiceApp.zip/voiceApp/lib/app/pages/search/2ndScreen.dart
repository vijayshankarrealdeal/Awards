import 'package:flutter/cupertino.dart';

class Search extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
