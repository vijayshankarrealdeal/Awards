import 'package:flutter/cupertino.dart';

class AddVoice extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
